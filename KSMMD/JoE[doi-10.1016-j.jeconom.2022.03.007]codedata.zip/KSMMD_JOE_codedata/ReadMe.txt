Pre-Requirements: 
R (https://www.r-project.org)
Rcpp (https://cran.r-project.org/package=Rcpp), 
RcppArmadillo (https://cran.r-project.org/package=RcppArmadillo), 
energy (https://CRAN.R-project.org/package=energy)
Rtools (https://cran.r-project.org/bin/windows/Rtools/),

Install the R package "kdiskertest" (from source):
install.packages("kdiskertest_1.0.1.tar.gz", repos = NULL)#R Code

For usage, please check the files "Testcommon.R", and "Example_Gini.R".
