#original data source: https://data.worldbank.org/indicator/SI.POV.GINI
#pre-processed

#All
Y <- readRDS(file = "Gini.Rds");
vn <- c(22,7,17);
source("Testcommon.R");

Y1 <- Y[,1:22];n1=22;
Y2 <- Y[,23:29];n2=7;
Y3 <- Y[,30:46];n3=17;

##Lower Middle vs Upper Middle
vn <- c(n2,n3);
Y<-cbind(Y2,Y3);
source("Testcommon.R");

#Lower Middle vs High
vn <- c(n2,n1);
Y<-cbind(Y2,Y1);
source("Testcommon.R");

#Upper Middle vs High
vn <- c(n3,n1);
Y<-cbind(Y3,Y1);
source("Testcommon.R");