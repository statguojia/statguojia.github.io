#expected input: Y:pxn (pooled/cbinded data matrix), vn=[n1,...,nk] (group sample sizes)
library("kdiskertest");
#install.packages("energy");
library("energy");

#calculate the kernel width's
d <- dist(t(Y));
md <- as.matrix(d);
ker_sigma2 <- median(c(md[lower.tri(md,FLASE)]));
ker_sigma2 <- ker_sigma2*ker_sigma2;#0.5*ker_sigma2 is the "median heuristic" for Tmed3c
gammas <- Ker_GRBF_sigma2_Rn(Y,vn);#sqrt(2)*gammas[1] is the width (41) for Tsd3c, gammas[1]=sqrt(htrSigma2)

#Tsd3c
zz_sd <- kdisRcpp(Y,vn,2,1,sqrt(2)*gammas[1]);#method=2: moment-matching approx (33); kertype=1: Gaussian radial basis function kernel (38)
print(zz_sd);#p-value,stat,df,beta0,beta1
print(paste("sqrt(2)*gammas[1]",sqrt(2)*gammas[1]));#

#Tmed3c
zz_med <- kdisRcpp(Y,vn,2,1,0.5*ker_sigma2);
print(zz_med);#p-value,stat,df,beta0,beta1
print(paste("0.5*ker_sigma2",0.5*ker_sigma2));#

#TSR: energy test of Sz��kely & Rizzo (2004)
sz <- eqdist.etest(d, sizes=vn, distance=TRUE, R=9999);
#sz <- eqdist.etest(t(Y), sizes=vn, distance=FALSE, R=199)
print(sz);#

tmp_results <- c(zz_sd[1],zz_med[1],sz$p.value,
                 zz_sd[3],zz_med[3],
                 sqrt(2)*gammas[1],0.5*ker_sigma2);